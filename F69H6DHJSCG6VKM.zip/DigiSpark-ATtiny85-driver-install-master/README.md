# DigiSpark-ATtiny85-driver-install

## install driver

![image](https://github.com/LilyGO/DigiSpark-ATtiny85-driver-install/blob/master/image/image1.png)

## board settin up
    
    http://digistump.com/package_digistump_index.json
![image](https://github.com/LilyGO/DigiSpark-ATtiny85-driver-install/blob/master/image/image3.png)

![image](https://github.com/LilyGO/DigiSpark-ATtiny85-driver-install/blob/master/image/image2.png)
